name="Trade Post Automation"
path="mod/trade_post_automation"
tags={ trade economy vanilla }
dependencies={
	
	# NB: Dependencies do not have to be present in the game!
	#     (In fact, it's impossible that all of these will be present.)
	#     This simply instructs the game engine to load these other mods first, if they exist.
	
	# MTR (all versions)
	"\"Medieval Trade Routes (Vanilla)\""
	"\"Medieval Trade Routes (CleanSlate)\""
	"\"Medieval Trade Routes (HIP map)\""
	
	# PDXRPTG mod & fixes
	"\"PDXRP Tamriel Game\""
	"\"Expanded Decisions: PDXRP Tamriel Game\""
	
	# Other total conversions with major changes
	"\"After the End Fan Fork\""
	"\"Warcraft: Guardians of Azeroth\""
	"\"Faerun - Forgotten Realms Total Conversion\""
	
	# Other total conversions with essentially no changes from the base game (in terms of trade mechanics, anyway)
	"\"Romance of the Three Kingdoms\""
	"\"Middle-Earth... in Earth !\""
	
}