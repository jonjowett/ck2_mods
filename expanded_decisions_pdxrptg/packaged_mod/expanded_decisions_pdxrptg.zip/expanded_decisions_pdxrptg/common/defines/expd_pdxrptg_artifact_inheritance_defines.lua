NDefines.NCharacter.TREASURY_CHANCE_TO_DISAPPEAR_STANDARD = 0 -- Chances that artifacts disappear on inheritance
NDefines.NCharacter.TREASURY_CHANCE_TO_DISAPPEAR_NO_HEIR = 0  -- Chances that artifacts disappear on inheritance when the dying character doesn't have an heir
